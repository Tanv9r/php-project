<body>
<header class="container mt-3">
	<a href="./" class="btn btn-info">home</a>
	<a href="./shop.php" class="btn btn-info">shop</a>
</header>