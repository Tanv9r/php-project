<?php
session_start();
//store this value to track loged in admin
$admin_email = $_SESSION['admin_email'];

//end here
if(empty($_SESSION['admin_email'])){
    header('location:login.php');
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>portfolio site</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
        <?php include 'sidebar.php';?>
        <div id="page-wrapper" >
            <div id="page-inner">
			<!-- for success message -->

			<?php
			if(isset($_SESSION['info'])){
				$info = $_SESSION['info'];
				?>
				<div>
				  <strong><?php echo $info;?></strong>
				</div>
				<?php
        unset($_SESSION['info']);
			}?>


			<!-- end success message -->
        <form method = "post" action = "educationvalidation.php">
  				<div class="mb-3">
  					<input type = "text" name = "admin_email" value = "<?php echo $admin_email;?>" readonly>
  				</div>
  				<div class="mb-3">
  					<input type = "number" name = "passing_year" placeholder = "Passing Year!">
  				</div>
  				<div class="mb-3">
  					<input type = "text" name = "institute_name" placeholder = "Institute Name!" required>
  				</div>
  				<div class="mb-3">
  					<input type = "text" name = "degree" placeholder = "Degree!" required>
  				</div>
  				<div class="mb-3">
  					<input type = "number" name = "grade" step="0.01" placeholder = "Grade hints:5.0 !" required>
  				</div>
  				<div class="mb-3">
  					<input type = "submit" name = "submit">
  				</div>
				</form>
    		</div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- MORRIS CHART SCRIPTS -->
     <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
