<?php
if(isset($_POST['submit'])){
  $id=$_POST['id'];
	$admin_email = $_POST['admin_email'];
	$passing_year = $_POST['passing_year'];
	$institute_name = $_POST['institute_name'];
	$degree = $_POST['degree'];
	$grade = $_POST['grade'];

	require 'config.php';
  $sql = "UPDATE education_admin SET institute_name='$institute_name',
                                  degree='$degree',
                                  grade='$grade'
                            WHERE id='$id'";
  $result=mysqli_query($conn,$sql);
  	if($result){
  		$_SESSION['info'] = "data update successfully";
  		header('location:educationview.php');
  	}


}
?>
