<!--header -->
<?php include './include/header.php';?>
<!--  end header -->

<!-- page top bar -->
<?php include './include/pagelinks.php';?>
<!-- end page top bar -->


	<!-- products section -->
	<?php include './include/products.php'; ?>
	<!-- end shop section -->





<!-- footer -->
<?php include './include/footer.php';?>
<!-- end footer -->