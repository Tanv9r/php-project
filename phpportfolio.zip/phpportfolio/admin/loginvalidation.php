<?php
require 'config.php';

if(isset($_POST['submit'])){

    $admin_email = $_POST['useremail'];
    $password = $_POST['password'];
    $sql= "SELECT * FROM admin WHERE admin_email = '$admin_email' AND password = '$password'";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result)>0){
        $row= mysqli_fetch_assoc($result);
        if($row['admin_email']==$admin_email && $row['password']==$password){
            $_SESSION['admin_email'] = $row['admin_email'];
            header('location:index.php');
        }
    }
    else{
        header('location:login.php');
    }
}

?>
