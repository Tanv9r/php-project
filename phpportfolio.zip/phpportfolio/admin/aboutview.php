<?php
require 'config.php';

if(empty($_SESSION['admin_email'])){
    header('location:login.php');
}
else{

	$sql="SELECT * FROM about_admin";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_num_rows($result);

}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Bootstrap Admin Template : Binary Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->

        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
     <!-- TABLE STYLES-->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <?php include 'sidebar.php';?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Database Tables</h2>
                        <h5>these tables are created by admin</h5>

                    </div>
                </div>

                 <hr />
                 <!-- ROW  -->
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">

                        <div class="panel-heading">
                            About Table

                        </div>
                        <?php
                        if(isset($_SESSION['info'])){
                          ?>
                          <strong><?php echo $_SESSION['info']; ?></strong>
                        <?php
                        unset($_SESSION['info']);
                        }
                        ?>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <?php
									if($row>0){

										while($data= mysqli_fetch_assoc($result)){


									?>


									<thead>
                                        <tr>
                                            <th>Admin Email</th>
                                            <th>Admin Name</th>
                                            <th>Admin Age</th>
                                            <th>Admin Qualification</th>
                                            <th>Admin Post</th>
                                            <th>Admin Language</th>
                                            <th>Admin Experience</th>
                                            <th>Admin Number of Project</th>
                                            <th>Admin Clients</th>
                                            <th>Admin Awards</th>
                                            <th>Action</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="odd gradeX">
                                          <form method="post" action="updateabout.php">
                                            <td><input type = "text" name = "admin_email" value="<?php echo $data['admin_email'];?>" readonly></td>
                                            <td><input type = "text" name = "admin_name" value="<?php echo $data['admin_name'];?>"></td>
                                            <td><input type = "number" name = "admin_age" value="<?php echo $data['admin_age'];?>"></td>
                                            <td><input type = "text" name = "admin_qualification" value="<?php echo $data['admin_qualification'];?>"></td>
                                            <td><input type = "text" name = "admin_post" value="<?php echo $data['admin_post'];?>"></td>
                                            <td><input type = "text" name = "admin_language" value="<?php echo $data['admin_language'];?>"></td>
                                            <td><input type = "text" name = "admin_experience" value="<?php echo $data['admin_experience'];?>"></td>
                                            <td><input type = "number" name = "admin_num_of_project" value="<?php echo $data['admin_num_of_project'];?>"></td>
                                            <td><input type = "number" name = "admin_clients" value="<?php echo $data['admin_clients'];?>"></td>
                                            <td><input type = "number" name = "admin_awards" value="<?php echo $data['admin_awards'];?>"></td>
                                            <td><input type="submit" name="submit" value="Update"></td>
                                            <form>
                                        </tr>
                                    </tbody>
									<?php
										}
									?>
									<?php
									}
									?>
                                </table>
                            </div>

                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->

        </div>

    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->


         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
