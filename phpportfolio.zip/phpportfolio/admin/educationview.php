<?php
require 'config.php';

if(empty($_SESSION['admin_email'])){
    header('location:login.php');
}
else{

	$sql="SELECT * FROM education_admin";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_num_rows($result);

}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Free Bootstrap Admin Template : Binary Admin</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->

        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
     <!-- TABLE STYLES-->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div id="wrapper">
        <?php include 'sidebar.php';?>
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Database Tables</h2>
                        <h5>these tables are created by admin</h5>

                    </div>
                </div>

                 <hr />
                 <!-- ROW  -->
            <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">

                        <div class="panel-heading">
                            Education Table

                        </div>
                        <?php
                        if(isset($_SESSION['info'])){
                          ?>
                          <strong><?php echo $_SESSION['info']; ?></strong>
                        <?php
                        unset($_SESSION['info']);
                        }
                        ?>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <?php
									if($row>0){

										while($data= mysqli_fetch_assoc($result)){


									?>


									<thead>
                                        <tr>
                                            <th>id</th>
                                            <th>Admin Email</th>
                                            <th>Passing Year</th>
                                            <th>Institute Name</th>
                                            <th>Degree</th>
                                            <th>Grade</th>
                                            <th>Action</th>
                                            <th>Action</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="odd gradeX">
                                          <form method="post" action="updateeducation.php">
                                            <td><input type = "number" name = "id" value="<?php echo $data['id'];?>" readonly></td>
                                            <td><input type = "text" name = "admin_email" value="<?php echo $data['admin_email'];?>" readonly></td>
                                            <td><input type = "number" name = "passing_year" value="<?php echo $data['passing_year'];?>"></td>
                                            <td><input type = "text" name = "institute_name" value="<?php echo $data['institute_name'];?>"></td>
                                            <td><input type = "text" name = "degree" value="<?php echo $data['degree'];?>"></td>
                                            <td><input type = "number" name = "grade" step="0.01" value="<?php echo $data['grade'];?>"></td>
                                            <td><input type="submit" name="submit" value="Update" class = "btn btn-success"></td>
                                            <td><a href="deleteeducation.php?id=<?php echo $data['id'];?>" onclick="return confirmDelete()" class="btn btn-danger">Delete</a></td>
                                            <form>
                                        </tr>
                                    </tbody>
									<?php
										}
									?>
									<?php
									}
									?>
                                </table>
                            </div>

                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
                <!-- /. ROW  -->

        </div>

    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
     <!-- DATA TABLE SCRIPTS -->


         <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
	
	<!-- delete confirmation -->
	<script>
	function confirmDelete(){
		return confirm('Confirm Delete');
	}
	</script>

</body>
</html>
