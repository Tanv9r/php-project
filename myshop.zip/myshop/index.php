<!--header -->
<?php include './include/header.php';?>
<!--  end header -->

<!-- page top bar -->
<?php include './include/pagelinks.php';?>
<!-- end page top bar -->



<!-- section start -->
	<!-- new_in_product_section -->
	<section class="container mt-3">
		<h3 class="text-center text-capitalize">new in</h3>
		<div class="row">
		<?php 
		$x=1;
		while($x <= 2){
		?>
		<div class="card m-3" style="width: 18rem;">
			<img src="img/Argentina-Away-Authentic-Jersey-World-Cup-2022.jpg">
			<div class="card-body">
				<h5 class="card-title">Argentina-Away-Authentic-Jersey-World-Cup-2022</h5>
				<p class="cart-text">৳ 1500 </p>
			</div>
			<a href="./checkout.php" class="btn btn-primary">Order Now</a>
		</div>
		<?php 
		$x++;
		}
		?>
		</div>
	</section>
	<!-- end new_in_product_section -->
	
	<section class="container mt-5">
		<h3 class="text-center text-capitalize">best sells</h3>
		<div class="row">
		<?php 
		$x=1;
		while($x <= 2){
		?>
		<div class="card m-3" style="width: 18rem;">
			<img src="img/Argentina-Away-Authentic-Jersey-World-Cup-2022.jpg">
			<div class="card-body">
				<h5 class="card-title">Argentina-Away-Authentic-Jersey-World-Cup-2022</h5>
				<p class="cart-text">৳ 1500 </p>
			</div>
			<a href="./checkout.php" class="btn btn-primary">Order Now</a>
		</div>
		<?php 
		$x++;
		}
		?>
		</div>
	</section>
	
	
	


<!-- end section -->



<!-- footer -->
<?php include './include/footer.php';?>
<!-- end footer -->