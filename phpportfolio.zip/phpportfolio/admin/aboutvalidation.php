<?php
if(isset($_POST['submit'])){
	$admin_email = $_POST['admin_email'];
	$admin_name = $_POST['admin_name'];
	$admin_age = $_POST['admin_age'];
	$admin_qualification = $_POST['admin_qualification'];
	$admin_post = $_POST['admin_post'];
	$admin_language = $_POST['admin_language'];
	$admin_experience = $_POST['admin_experience'];
	$admin_num_of_project = $_POST['admin_num_of_project'];
	$admin_clients = $_POST['admin_clients'];
	$admin_awards = $_POST['admin_awards'];

	require 'config.php';
  $checkdata = "SELECT * FROM about_admin WHERE admin_email = '$admin_email'";
  $checkresult=mysqli_query($conn,$checkdata);
  if(mysqli_num_rows($checkresult)>0){
    $_SESSION['info'] = "email allready exists";
		header('location:about.php');
  }
  else{
  	$sql = "INSERT INTO about_admin (admin_email, admin_name, admin_age, admin_qualification,
                    admin_post, admin_language, admin_experience, admin_num_of_project,
  									admin_clients, admin_awards)
  									VALUES('$admin_email','$admin_name','$admin_age','$admin_qualification',
                      '$admin_post','$admin_language','$admin_experience','$admin_num_of_project',
                      '$admin_clients','$admin_awards')";

  	$result = mysqli_query($conn, $sql);
  	if($result){
  		$_SESSION['info'] = "data added successfully";
  		header('location:about.php');
  	}
  }


}
?>
