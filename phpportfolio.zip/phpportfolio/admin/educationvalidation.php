<?php
if(isset($_POST['submit'])){
	$admin_email = $_POST['admin_email'];
	$passing_year = $_POST['passing_year'];
	$institute_name = $_POST['institute_name'];
	$degree = $_POST['degree'];
	$grade = $_POST['grade'];

	require 'config.php';

  	$sql = "INSERT INTO education_admin (admin_email, passing_year,
                                        institute_name, degree,
                                        grade)
  									VALUES('$admin_email','$passing_year','$institute_name',
                      '$degree','$grade')";

  	$result = mysqli_query($conn, $sql);
  	if($result){
  		$_SESSION['info'] = "data added successfully";
  		header('location:education.php');
  	}


}
?>
