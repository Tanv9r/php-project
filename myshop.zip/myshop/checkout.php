<?php include './include/header.php';?>
<?php include './include/pagelinks.php';?>
<section class ="container text-center" style="margin-top: 100px;">
	<h1>নাম, ঠিকানা, মোবাইল নাম্বার লিখে Place Order ক্লিক করুন।</h1>
</section>

<section class="container mt-5">
		
	<form class="row">
		<div class="col-md-7">
			<div class="col-md-3">
				<label for="name">Your Name *...</label>
				<input class="form-control" name="name" type="text"><br>
			</div>
			<div class="col-sm-5">
				<label for="address">Street address *...</label>
				<input class="form-control" name="address" type="text" placeholder="your current address"><br>
			</div>
			<div class="col-sm-5">
				<label for="number">Mobile Number *...</label>
				<input class="form-control" name="number" type="text"><br>
			</div>
		</div>
			
		<div class="col-md-5">
			<h3 class="text-start text-capitalize">Your order</h3>
			<table class="table table-borderless">
			<thead>
			<tr>
			<th scope="col">Product</th>
			<th scope="col">subtotal</th>
			</tr>
			</thead>
			<tbody>
			<tr>
			<td>Mini Portable Swing Machine  × 2	</td>
			<td>৳ 2,900</td>
			</tr>
			</tbody>
				
				
			</table>
		</div>
	</form>
		
</section>
<?php include './include/footer.php';?>