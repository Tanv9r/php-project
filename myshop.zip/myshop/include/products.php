<section class="container">

	<div class="row">
	<?php 
	$x=1;
	while($x <= 5){
	?>
	<div class="card m-3" style="width: 18rem;">
		<img src="img/Argentina-Away-Authentic-Jersey-World-Cup-2022.jpg">
		<div class="card-body">
			<h5 class="card-title">Argentina-Away-Authentic-Jersey-World-Cup-2022</h5>
			<p class="cart-text">৳ 1500 </p>
		</div>
		<a href="./checkout.php" class="btn btn-primary">Order Now</a>
	</div>
	<?php 
	$x++;
	}
	?>
	</div>
	
</section>