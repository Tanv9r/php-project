<?php
require 'config.php';
$id=$_GET['id'];
$sql= "DELETE FROM education_admin WHERE id = '$id'";
$result = mysqli_query($conn, $sql);
$_SESSION['info'] = "data deleted successfully";
header('location:educationview.php');
?>
